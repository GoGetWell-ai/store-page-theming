import Views from './Views'

export default Views
