import SignUp from './SignUp'

export { SignUpBase } from './SignUp'
export default SignUp
