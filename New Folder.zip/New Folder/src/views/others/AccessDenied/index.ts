import AccessDenied from './AccessDenied'

export default AccessDenied
