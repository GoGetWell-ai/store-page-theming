import ChatBox from './ChatBox'

export type { ScrollBarRef } from './types'
export type { ChatBoxProps, MessageList } from './ChatBox'

export default ChatBox
