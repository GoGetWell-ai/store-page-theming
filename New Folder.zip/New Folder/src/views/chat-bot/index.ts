import Chat from './GenerativeChat'

export default Chat
