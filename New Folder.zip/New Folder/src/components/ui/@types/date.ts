export type FirstDayOfWeek = 'sunday' | 'monday'
