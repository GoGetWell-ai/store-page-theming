import Button from './Button'

export type { ButtonProps } from './Button'
export { Button }

export default Button
