import Dialog from './Dialog'

export type { DialogProps } from './Dialog'
export { Dialog }

export default Dialog
