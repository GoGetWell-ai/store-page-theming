import Spinner from './Spinner'

export type { SpinnerProps } from './Spinner'

export { Spinner }

export default Spinner
