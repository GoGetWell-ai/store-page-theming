import Badge from './Badge'

export type { BadgeProps } from './Badge'
export { Badge }

export default Badge
