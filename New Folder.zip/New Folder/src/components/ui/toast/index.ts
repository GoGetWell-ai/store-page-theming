import toast from './toast'

export type { ToastProps } from './ToastWrapper'
export { toast }

export default toast
