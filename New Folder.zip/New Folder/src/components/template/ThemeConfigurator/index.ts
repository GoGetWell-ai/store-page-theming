import ThemeConfigurator from './ThemeConfigurator'

export type { ThemeConfiguratorProps } from './ThemeConfigurator'

export default ThemeConfigurator
