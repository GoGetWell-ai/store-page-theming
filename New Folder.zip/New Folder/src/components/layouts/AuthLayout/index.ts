import AuthLayout from './AuthLayout'

export default AuthLayout
