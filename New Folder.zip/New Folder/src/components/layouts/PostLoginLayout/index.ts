import PostLoginLayout from './PostLoginLayout'

export default PostLoginLayout
