export const signInUserData = [
    {
        id: '21',
        avatar: '',
        userName: 'John Doe',
        email: 'admin-01@ecme.com',
        authority: ['admin', 'user'],
        password: '123Qwe',
        accountUserName: 'admin',
    },
]
