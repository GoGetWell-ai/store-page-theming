export const notificationListData = []

export const searchQueryPoolData = []