export const ADMIN = 'admin'
export const USER = 'user'
